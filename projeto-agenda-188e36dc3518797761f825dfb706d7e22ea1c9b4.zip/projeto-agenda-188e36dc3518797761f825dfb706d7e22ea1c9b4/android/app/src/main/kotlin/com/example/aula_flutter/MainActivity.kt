package com.example.aula_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
